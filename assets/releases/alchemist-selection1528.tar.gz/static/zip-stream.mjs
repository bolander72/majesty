// Stored ZIP exports: serial source reads, an awaited sink and a disk index.
import { crc32 } from "./core.js";

export const ZIP_READ_BYTES = 65536;
const U32 = 0xffffffff;
const FLAGS = 0x0808; // UTF-8 names and a signed data descriptor (APPNOTE 4.3.9).

function check(signal) { if (signal?.aborted) throw new DOMException("Save export cancelled", "AbortError"); }
function bounds(value) {
  if (!Number.isSafeInteger(value) || value < 0 || value >= U32)
    throw new Error("This backup is too large for a single ZIP archive.");
  return value;
}
function header(name, file, offset) {
  if (typeof name !== "string" || !name || name.startsWith("/") || name.includes("\\") ||
      name.split("/").some(p => !p || p === "." || p === "..") || name.includes("\0"))
    throw new Error("Invalid save export path");
  const encoded = new TextEncoder().encode(name);
  if (encoded.length > 65535) throw new Error("Save export path is too long");
  bounds(file.size); bounds(offset + 30 + encoded.length + file.size + 16);
  const date = new Date(file.lastModified ?? Date.now());
  const year = Math.max(1980, Math.min(2107, date.getFullYear()));
  const time = (date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1);
  const day = ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  const local = new DataView(new ArrayBuffer(30));
  local.setUint32(0, 0x04034b50, true); local.setUint16(4, 20, true);
  local.setUint16(6, FLAGS, true); local.setUint16(10, time, true); local.setUint16(12, day, true);
  local.setUint16(26, encoded.length, true);
  return {encoded, local:new Uint8Array(local.buffer), time, day};
}
function records(h, size, crc, offset) {
  const descriptor = new DataView(new ArrayBuffer(16));
  descriptor.setUint32(0, 0x08074b50, true); descriptor.setUint32(4, crc, true);
  descriptor.setUint32(8, size, true); descriptor.setUint32(12, size, true);
  const central = new DataView(new ArrayBuffer(46));
  central.setUint32(0, 0x02014b50, true); central.setUint16(4, 20, true); central.setUint16(6, 20, true);
  central.setUint16(8, FLAGS, true); central.setUint16(12, h.time, true); central.setUint16(14, h.day, true);
  central.setUint32(16, crc, true); central.setUint32(20, size, true); central.setUint32(24, size, true);
  central.setUint16(28, h.encoded.length, true); central.setUint32(42, offset, true);
  return {descriptor:new Uint8Array(descriptor.buffer), central:new Uint8Array(central.buffer)};
}
function ending(count, size, offset) {
  bounds(offset + size + 22);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, count, true); end.setUint16(10, count, true);
  end.setUint32(12, size, true); end.setUint32(16, offset, true);
  return new Uint8Array(end.buffer);
}
async function fileCrc(file, size, signal, consume) {
  if (file.size !== size) throw new Error("Save changed while exporting");
  let crc = 0;
  for (let at = 0; at < size; at += ZIP_READ_BYTES) {
    check(signal);
    const n = Math.min(ZIP_READ_BYTES, size - at);
    const bytes = new Uint8Array(await file.slice(at, at + n).arrayBuffer());
    if (bytes.length !== n || file.size !== size) throw new Error("Save changed while exporting");
    check(signal); crc = crc32(bytes, crc); if (consume) await consume(bytes);
  }
  check(signal);
  if (file.size !== size) throw new Error("Save changed while exporting");
  return crc;
}

// entries yields {name, file}. central writes metadata and later yields it in
// bounded chunks. Neither source contents nor directory records form a queue.
export async function zipWriteStream(entries, output, central, {signal} = {}) {
  let offset = 0, count = 0, centralSize = 0;
  for await (const {name, file} of entries) {
    check(signal); if (count >= 65534) throw new Error("This backup has too many files for a single ZIP archive.");
    const h = header(name, file, offset), size = file.size;
    bounds(centralSize + 46 + h.encoded.length);
    await output.write(h.local); await output.write(h.encoded);
    const crc = await fileCrc(file, size, signal, bytes => output.write(bytes));
    const r = records(h, size, crc, offset);
    await output.write(r.descriptor); await central.write(r.central); await central.write(h.encoded);
    offset += 30 + h.encoded.length + size + 16; centralSize += 46 + h.encoded.length; ++count;
  }
  const end = ending(count, centralSize, offset); let copied = 0;
  for await (const bytes of central.chunks()) {
    check(signal);
    if (!(bytes instanceof Uint8Array) || !bytes.length || bytes.length > ZIP_READ_BYTES || copied + bytes.length > centralSize)
      throw new Error("Invalid ZIP index stream");
    await output.write(bytes); copied += bytes.length;
  }
  if (copied !== centralSize) throw new Error("Truncated ZIP index");
  check(signal); await output.write(end);
  return {count, bytes:offset + centralSize + 22};
}

// Download fallback retains File references and small headers, not complete
// source ArrayBuffers. Blob internals and metadata growth need browser testing.
export async function zipWriteFileBlobs(entries, {signal} = {}) {
  const parts = [], index = []; let offset = 0, count = 0, centralSize = 0;
  for await (const {name, file} of entries) {
    check(signal); if (count >= 65534) throw new Error("This backup has too many files for a single ZIP archive.");
    const h = header(name, file, offset), size = file.size;
    bounds(centralSize + 46 + h.encoded.length);
    const crc = await fileCrc(file, size, signal), r = records(h, size, crc, offset);
    parts.push(h.local, h.encoded, file, r.descriptor); index.push(r.central, h.encoded);
    offset += 30 + h.encoded.length + size + 16; centralSize += 46 + h.encoded.length; ++count;
  }
  check(signal);
  return {blob:new Blob([...parts, ...index, ending(count, centralSize, offset)], {type:"application/zip"}), count};
}
