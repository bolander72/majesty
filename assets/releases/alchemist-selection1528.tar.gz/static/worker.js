// worker.js - imports, status and saves in the origin private file system
// (OPFS), off the page's thread. Layout: /<game id>/game/... (the game, its
// .manifest.json and .stamp) and /<game id>/profile/... (saves and settings).
import { importGame, gameStatus, ZipReader, Sha256 } from "./core.js";
import { zipWriteStream, zipWriteFileBlobs, ZIP_READ_BYTES } from "./zip-stream.mjs";

let controller = null;
let exporting = false;

async function dirFor(path, create = true) {
  let dir = await navigator.storage.getDirectory();
  for (const part of path.split("/").filter(Boolean))
    dir = await dir.getDirectoryHandle(part, { create });
  return dir;
}

async function fileFor(root, rel, create) {
  const parts = rel.split("/");
  const name = parts.pop();
  let dir = root;
  for (const p of parts) dir = await dir.getDirectoryHandle(p, { create });
  return dir.getFileHandle(name, { create });
}

function opfsStore(root) {
  return {
    async readText(rel) {
      try {
        return await (await (await fileFor(root, rel, false)).getFile()).text();
      } catch {
        return null;
      }
    },
    async writeText(rel, text) {
      const handle = await fileFor(root, rel, true);
      const access = await handle.createSyncAccessHandle();
      const bytes = new TextEncoder().encode(text);
      access.truncate(0);
      access.write(bytes, { at: 0 });
      access.flush();
      access.close();
    },
    async remove(rel) {
      const parts = rel.split("/");
      const name = parts.pop();
      try {
        let dir = root;
        for (const p of parts) dir = await dir.getDirectoryHandle(p);
        await dir.removeEntry(name);
      } catch {}
    },
    async hash(rel) {
      const file = await (await fileFor(root, rel, false)).getFile();
      const sha = new Sha256();
      const reader = file.stream().getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        sha.update(value);
      }
      return sha.hex();
    },
    // The manifest, written only after close, is what marks a file complete,
    // so a file cut short is never trusted and is simply written again.
    async createWriter(rel) {
      const handle = await fileFor(root, rel, true);
      const access = await handle.createSyncAccessHandle();
      access.truncate(0);
      let at = 0;
      return {
        async write(bytes) {
          const n = access.write(bytes, { at });
          if (n !== bytes.length) throw new DOMException("short write", "QuotaExceededError");
          at += n;
        },
        async close() {
          access.flush();
          access.close();
        },
        async abort() {
          try { access.close(); } catch {}
        },
      };
    },
  };
}

// Sources ---------------------------------------------------------------
function filesSource(files) {
  // [{path, file}] from a folder input or a drop.
  const entries = files.map(({ path, file }) => ({
    path: path.replaceAll("\\", "/").replace(/^\/+/, ""),
    size: file.size,
    mtime: Math.floor((file.lastModified || 0) / 1000),
    isDir: false,
    file,
  }));
  return { list: async () => entries, stream: async (e) => e.file.stream() };
}

async function handleSource(dirHandle) {
  const entries = [];
  const walk = async (dir, prefix) => {
    for await (const [name, h] of dir.entries()) {
      const path = prefix ? prefix + "/" + name : name;
      if (h.kind === "directory") {
        entries.push({ path, size: 0, mtime: 0, isDir: true });
        await walk(h, path);
      } else {
        const file = await h.getFile();
        entries.push({ path, size: file.size, mtime: Math.floor(file.lastModified / 1000), isDir: false, file });
      }
    }
  };
  await walk(dirHandle, dirHandle.name);
  return { list: async () => entries, stream: async (e) => e.file.stream() };
}

async function zipSource(file) {
  const zip = await ZipReader.open(file);
  return { list: async () => zip.entries(), stream: (e) => zip.stream(e) };
}

async function freeBytes() {
  try {
    const { quota, usage } = await navigator.storage.estimate();
    return quota - usage;
  } catch {
    return undefined;
  }
}

// Pull only the next file after the previous file has reached the sink.
async function* saveFiles(dir, prefix = "", depth = 0) {
  if (depth > 64) throw new Error("Save directory nesting is too deep");
  for await (const [name, handle] of dir.entries()) {
    const path = prefix ? prefix + "/" + name : name;
    if (handle.kind === "directory") yield* saveFiles(handle, path, depth + 1);
    else yield {name:path, file:await handle.getFile()};
  }
}

async function exportSaveFile(game, root, destination) {
  const entries = saveFiles(root);
  let temporary, indexName, name, access, output, created = false, committed = false;
  try {
    const first = await entries.next();
    if (first.done) return {count:0, saved:false};
    temporary = await dirFor(game.id + "/export-tmp");
    indexName = "index-" + crypto.randomUUID();
    access = await (await temporary.getFileHandle(indexName, {create:true})).createSyncAccessHandle();
    access.truncate(0); let size = 0;
    const index = {
      async write(bytes) {
        if (access.write(bytes, {at:size}) !== bytes.length) throw new Error("Could not write backup index");
        size += bytes.length;
      },
      async* chunks() {
        access.flush();
        for (let at = 0; at < size; at += ZIP_READ_BYTES) {
          const bytes = new Uint8Array(Math.min(ZIP_READ_BYTES, size - at));
          if (access.read(bytes, {at}) !== bytes.length) throw new Error("Could not read backup index");
          yield bytes;
        }
      },
    };
    // A Save As picker can truncate a selected existing file before returning.
    // Instead, create a fresh name in the chosen folder; never reuse a backup.
    const title = Array.from((game.title || game.id).replace(/[^\p{L}\p{N} _.-]/gu, "_")).slice(0, 40).join("") || "Game";
    for (let attempt = 0; attempt < 8; ++attempt) {
      name = `${title} saves ${new Date().toISOString().replaceAll(":", "-")}-${crypto.randomUUID()}.zip`;
      try { await destination.getFileHandle(name); }
      catch (error) { if (error.name === "NotFoundError") break; throw error; }
      name = null;
    }
    if (!name) throw new Error("Could not choose a new backup filename");
    const file = await destination.getFileHandle(name, {create:true}); created = true;
    output = await file.createWritable();
    async function* remaining() { yield first.value; yield* entries; }
    const result = await zipWriteStream(remaining(), output, index);
    await output.close(); committed = true;
    output = null;
    return {count:result.count, saved:true, name};
  } finally {
    try { if (output) await output.abort(); }
    finally {
      try { if (access) access.close(); }
      finally {
        try {
          if (temporary && indexName) await temporary.removeEntry(indexName).catch(() => {});
          if (created && !committed) await destination.removeEntry(name).catch(() => {});
        } finally { await entries.return(); }
      }
    }
  }
}

// Messages --------------------------------------------------------------
const handlers = {
  async status({ game }) {
    const root = await dirFor(game.id + "/game");
    const status = await gameStatus(game, opfsStore(root));
    const estimate = await navigator.storage.estimate().catch(() => ({}));
    const persisted = await navigator.storage.persisted?.().catch(() => false);
    return { status, estimate, persisted };
  },
  async import({ game, kind, files, handle, file }) {
    controller = new AbortController();
    let source;
    if (kind === "files") source = filesSource(files);
    else if (kind === "handle") source = await handleSource(handle);
    else source = await zipSource(file);
    const root = await dirFor(game.id + "/game");
    const outcome = await importGame(game, source, opfsStore(root), {
      signal: controller.signal,
      freeBytes: await freeBytes(),
      onProgress: (p) => postMessage({ progress: p }),
    });
    controller = null;
    return outcome;
  },
  async cancel() {
    if (controller) controller.abort();
    return {};
  },
  async delete({ game }) {
    const dir = await dirFor(game.id);
    await dir.removeEntry("game", { recursive: true }).catch(() => {});
    return {};
  },
  async exportSaves({ game, destination }) {
    if (exporting) throw new Error("A save backup is already running");
    exporting = true;
    try {
      const dir = await dirFor(game.id + "/profile");
      return destination ? await exportSaveFile(game, dir, destination) : await zipWriteFileBlobs(saveFiles(dir));
    } finally { exporting = false; }
  },
  async importSaves({ game, file }) {
    const zip = await ZipReader.open(file);
    const root = await dirFor(game.id + "/profile");
    const store = opfsStore(root);
    let count = 0;
    for (const e of zip.entries()) {
      if (e.isDir || e.path.split("/").some((p) => p === "..")) continue;
      const w = await store.createWriter(e.path);
      const reader = (await zip.stream(e)).getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        await w.write(value);
      }
      await w.close();
      count++;
    }
    return { count };
  },
};

onmessage = async ({ data }) => {
  const { id, cmd } = data;
  try {
    const result = await handlers[cmd](data);
    postMessage({ id, result });
  } catch (e) {
    controller = null;
    postMessage({ id, error: String((e && e.message) || e) });
  }
};
